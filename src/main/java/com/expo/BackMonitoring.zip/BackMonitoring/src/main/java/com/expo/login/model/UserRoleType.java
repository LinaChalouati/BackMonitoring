package com.expo.login.model;

public enum UserRoleType {
    ADMIN,
    USER,
    EDITOR,
    VIEWER
}

