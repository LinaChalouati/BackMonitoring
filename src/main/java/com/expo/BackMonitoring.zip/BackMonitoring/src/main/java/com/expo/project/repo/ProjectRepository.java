package com.expo.project.repo;

import com.expo.project.model.Project;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectRepository extends JpaRepository<Project, Long> {
    Project findProjectById(Integer id);
    Project findByProjectName(String projectName);
}
