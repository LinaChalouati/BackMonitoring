package com.expo.prometheus.model;

public class CustomMetrics {
}
