package com.expo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExpoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExpoApplication.class, args);

	}

}
